<!DOCTYPE html>
<html> 
      
<head> 
    <title> 
      Paper Submission System
    </title> 
</head> 
  
<body style="text-align:center;"> 
<?php
	session_start();
	include('database.php');
	$globaldata = array();
        $editorGlobalData = array();
	if(array_key_exists('assignButton', $_POST)) {
            assignButton();
        }
        else if(array_key_exists('editorSubmitButton', $_POST)) {
            editorSubmitButton();
        }
        else if(array_key_exists('editorDeadlineButton', $_POST)) {
            editorDeadlineButton();
        }

            ?>
            <form method="post"> 
            <input type="submit" name="editorDeadlineButton"
                    class="button" value="Assign" /> 
            </form>
            <?php
        function assignButton()
        {
            echo "Now select the files you want to assign: ";
            $submissions = getAllSubmissions();
            for($a = 0; $a < count($submissions); $a++)
                    {
                    ?>
                    <form method="post">
                     <input type="checkbox" name="editorData[]" value="<?php echo $submissions[$a][0] ?>" /> <?php echo $submissions[$a][0]?>
                     
                     <?php
                    }
                    ?>
                        <input type="submit" name="editorSubmitButton"
                               class="button" value="Assign" />                     
                        </form> 
                    <?php
        }
        function editorDeadlineButton()
        {
            echo 'Please chose the deadline of the submissions first: ';
            ?>
            <form method="post">
            <input type="date" name="deadline" value="yyyy/mm/dd" />
            <input type="submit" name="assignButton"
                   class="button" value="Set Deadline" /> 
            </form> 
            <?php
            $exp_date = strtotime($_POST['deadline']);
            $deadlineLocal = date("Y-m-d",strtotime($exp_date));
            $_SESSION['deadlineSession'] = $deadline;

        }
        function editorSubmitButton()
        {
            if(!empty($_POST["editorData"]))
            {
                global $editorGlobalData;
                echo '<h3>you have assigned the following</h3>';
                foreach($_POST["editorData"] as $data)
                {
                    echo '<p>' .$data. '</p>';
                    addReview($data, 0);
                }
                $_SESSION['chosen'] = $editorGlobalData;
                global $editorDeadline;
                print_r($editorDeadline);
                echo " With the following deadline: " .$_SESSION['deadlineSession']. "<br>";
            }
            else
            {
                echo 'please select at least one';
            }            
        }
?>
<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
</body>

</html>
	
