
<form method="POST" enctype="multipart/form-data" action="upload.php">
	<input type="file" name="file">
	<input type="submit" value="Upload">
	<input type="hidden" name="subId" value="<?php echo $_POST['subId'] ?>">
</form>


<?php
session_start();

include('database.php');

// creating file to upload
//displaying all uploaded files

$submission = getSubmission($_POST['subId']);
	//displaying links to download
	//making it downloadable
	?>
	<p>
	File:
	<a download="<?php echo $submission[1] ?>" href="uploads/<?php echo $submission[1] ?>"><?php echo $submission[1] ?></a>
	Status:
	<div><?php echo $submission[2]?></div>
	</p>

