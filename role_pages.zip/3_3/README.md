# SENG
SENG_300 Winter 2020

Academic Paper Submission System

-- AGILE Scrum methodology used.

Very helpful to have XAMPP installed in your device. (https://www.apachefriends.org/index.html)

Once you have XAMPP, open XAMPP control panel, start the Apache and MySQL servers.

Go to C:\xampp\htdocs, create a folder, unzip and paste the source code in this folder.

Open a web browser and type in localhost/path/to/folder(eg: localhost/folder/), you should be able to view the website now.
