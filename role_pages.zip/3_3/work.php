
<form method="POST" enctype="multipart/form-data" action="upload.php">
	<input type="file" name="file">
	<input type="submit" value="Upload">
	<input type="hidden" name="subId" value="<?php echo $_POST['subId'] ?>">
</form>


<?php
session_start();

include('database.php');

// creating file to upload
//displaying all uploaded files

if(array_key_exists('nominateButton', $_POST)) {
	nominateButton();
}

$submission = getSubmission($_POST['subId']);
	//displaying links to download
	//making it downloadable
	if($submission) {
	?>
	<p>
	File:
	<a download="<?php echo $submission[1] ?>" href="uploads/<?php echo $submission[1] ?>"><?php echo $submission[1] ?></a>
	<div>status:</div>
	<div><?php echo $submission[2]?></div>
	</p>
	<p>
	Nominate Reviewers:
	</p>
	<?php 
	$reviewers = getReviewers();
	for($i = 0;$i < count($reviewers);$i++) {
	?>
		<form method="post">
                     <input type="checkbox" name="nominations[]" value="<?php echo $reviewers[$i][0] ?>" /> <?php echo $reviewers[$i][1]?>
                     
                     <?php
                    }
                    ?>
                        
                        <input type="submit" name="nominateButton"
                               class="button" value="Nominate" /> 
			<input type="hidden" name="subId" value="<?php echo $submission[0] ?>" />
                        </form>
	
<?php	}
function nominateButton() {
	if(!empty($_POST['nominations'])) {
		foreach($_POST['nominations'] as $data) {
			addNomination($_POST['subId'], $data);
		}
		?>
		<p>Reviewers have been nominated</p>
		<?php
	}
}


