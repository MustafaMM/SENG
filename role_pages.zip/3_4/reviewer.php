<html> 
      
<head> 
    <title> 
      Paper Submission System
    </title> 
</head> 

<body style="text-align:center;"> 
      
    <h1 style="color:green;"> 
       Paper Submission System
    </h1> 
    
	<?php
	        session_start();
		include("database.php");

        	if(array_key_exists('button3', $_POST)) {
        	    button3($_POST["reviewId"], $_POST["feedback"]);
        	}
        	else if(array_key_exists('button4', $_POST)) {
        	    	button4($_POST["reviewId"], $_POST["feedback"]);
        	}
		else if(array_key_exists('submitButton', $_POST)) {
            		submitButton();
        	}
		?>
		<h4>Your assigned topics</h4>
		<?php
		$submissions = getReviewerReviews($_SESSION['userId']);

                for($a = 0; $a < count($submissions); $a++)
                    {
			
                        //displaying links to download
                        //making it downloadable
                        ?>
                        <p>
                        <a download="<?php echo getSubmission($submissions[$a][1])[1] ?>" href="uploads/<?php echo getSubmission($submissions[$a][1])[1]?>"><?php echo getSubmission($submissions[$a][1])[1] ?></a>
			    <div><?php echo getSubmission($submissions[$a][1])[2]?></div>
                                <form method="post" name="recommendation" id="recommendation"> 
				<textarea name="feedback" rows="5" cols="50" form="recommendation"></textarea>
                                <input type="submit" name="button3" 
                                       class="button" value= "Accept"/>
                                <input type="submit" name="button4" 
                                       class="button" value= "Reject"/>
				<input type="hidden" name="reviewId" value="<?php echo $submissions[$a][0] ?>">
                                </form> 
                        </p>
                        <?php
                    } 
		$submissions = getAllSubmissions();
                    //checkbox code
                    for($a = 0; $a < count($submissions); $a++)
                    {
                    ?>
		<h4>Request Submissions to Review</h4>
                    <form method="post">
                     <input type="checkbox" name="data[]" value="<?php echo $submissions[$a][0] ?>" /> <a download="<?php echo $submissions[$a][1] ?>" href="uploads/<?php echo $submissions[$a][1]?>"><?php echo $submissions[$a][1] ?></a>
                     
                     <?php
                    }
                    ?>
                        
                        <input type="submit" name="submitButton"
                               class="button" value="Submit" /> 
                        </form> 
			<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
	<?php 
		function button3($reviewId, $feedback){
	    		updateReviewStatus($reviewId, "Accepted", $feedback);
	    
            		echo '<span style="color:#12EB2B;text-align:center;">You have accepted the submission!</span>';
			header('location: reviewer.php');
        	}
        	function button4($reviewId, $feedback){
	    		updateReviewStatus($reviewId, "Rejected", $feedback);
            		echo '<span style="color:#F10719;text-align:center;">You have rejected the submission.</span>';
			header('location: reviewer.php');
        	}
		function submitButton()
        	{
            		if(!empty($_POST["data"]))
            		{
                		echo '<h3>you have selected the following</h3>';
                		foreach($_POST["data"] as $data)
                		{
                    			echo '<p>' .$data. '</p>';
                    			addRequest($data, $_SESSION['userId']);
                		}
            		}
            		else
            		{
                		echo 'please select at least one';
            		}
        }
	?>

</body>

</html>
