<!DOCTYPE html>
<html> 
      
<head> 
    <title> 
      Paper Submission System
    </title> 
</head> 
  
<body style="text-align:center;"> 

<?php
	session_start();
	include('database.php');
	if(array_key_exists('assignButton', $_POST)) {
		assignButton();
	}
	$submissions = getAllSubmissions();
	for($i = 0;$i < count($submissions);$i++) {
		?>
		<p>Submission Id: <?php echo $submissions[$i][0] ?>	Status: <?php echo $submissions[$i][2]?></p>
		<?php
		$nominations = getSubmissionNominations($submissions[$i][0]);
		$requests = getSubmissionRequests($submissions[$i][0]);
		?>
		<h4>Nominated Reviewers:</h4>
		<?php
		for($j = 0;$j < count($nominations);$j++) {
			?>
			<p><?php echo getUserIdInfo($nominations[$j][1])[1]?></p>
		<?php
		}
		?>
		<h4>Requested Reviewers:</h4>
		<?php
		for($j = 0;$j < count($requests);$j++) {
			?>
			<p><?php echo getUserIdInfo($requests[$j][1])[1]?></p>
		<?php
		$reviewers = getReviewers();
		
		for($j = 0;$j < count($reviewers);$j++) {
		?>
		<form method="post">
                     <input type="checkbox" name="assigned[]" value="<?php echo $reviewers[$i][0] ?>" /> <?php echo $reviewers[$i][1]?>
                     
                     <?php
                    }
                    ?>
                        
                        <input type="submit" name="assignButton"
                               class="button" value="Assign" /> 
			<input type="hidden" name="subId" value="<?php echo $submissions[$i][0] ?>" />
                        </form>
		<?php
		}
	}
	function assignButton() {
		if(!empty($_POST['assigned'])) {
			foreach($_POST['assigned'] as $data) {
				addReview($_POST['subId'], $data);
			}
		}
	}

?>

</body>

</html>
