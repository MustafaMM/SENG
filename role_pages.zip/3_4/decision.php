<!DOCTYPE html>
<html> 
      
<head> 
    <title> 
      Paper Submission System
    </title> 
</head> 
  
<body style="text-align:center;"> 
	<?php
		session_start();
		include('database.php');
		if(array_key_exists('button3', $_POST)) {
        	    button3($_POST["subId"]);
        	}
        	else if(array_key_exists('button4', $_POST)) {
        	    	button4($_POST["subId"]);
        	}
		$submissions = getAllSubmissions();

                for($a = 0; $a < count($submissions); $a++)
                    {
			
                        //displaying links to download
                        //making it downloadable
                        ?>
                        <p>
                        <a download="<?php echo $submissions[$a][1] ?>" href="uploads/<?php echo $submissions[$a][1] ?>"><?php echo $submissions[$a][1] ?></a>
			    <div><?php echo $submissions[$a][2]?></div>
			<div>Recommendations:</div>
			<?php
				$reviews = getSubmissionReviews($submissions[$a][0]);
				for($j = 0;$j < count($reviews);$j++) {
					?>
						<div><?php echo getUserIdInfo($reviews[$j][2])[1] ?></div>
						<div><?php echo $reviews[$j][3] ?></div>
						<div>Comments:</div>
						<div><?php echo $reviews[$j][5]?></div>
					<?php
				}
			?>
                                <form method="post"> 
                                <input type="submit" name="button3" 
                                       class="button" value= "Accept"/>
                                <input type="submit" name="button4" 
                                       class="button" value= "Reject"/>
				<input type="hidden" name="subId" value="<?php echo $submissions[$a][0] ?>">
                                </form> 
                        </p>
                        <?php
                    } 
		function button3($subId){
	    		updateSubmissionStatus($subId, "Accepted");
	    
            		echo '<span style="color:#12EB2B;text-align:center;">You have accepted the submission!</span>';
			header('location: decision.php');
        	}
        	function button4($subId){
	    		updateSubmissionStatus($subId, "Rejected");
            		echo '<span style="color:#F10719;text-align:center;">You have rejected the submission.</span>';
			header('location: decision.php');
        	}
?>
</body>

</html>
