<!DOCTYPE html>
<html> 
      
<head> 
    <title> 
      Paper Submission System
    </title> 
</head> 
  
<body style="text-align:center;"> 

<a href="assign.php"><button type="button">Assign Reviewers</button></a>
<a href="decision.php"><button type="button">Review Submissions</button></a>

<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
</body>

</html>
