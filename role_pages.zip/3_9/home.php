<?php
	session_start();
	if($_SESSION['role'] == "Researcher") {
		header('location: researcher.php');
	}
	elseif($_SESSION['role'] == "Reviewer") {
		header('location: reviewer.php');
	}
	elseif($_SESSION['role'] == "Editor") {
		header('location: editor.php');
	}
	else {
		header('location: index.php');
	}
?>
