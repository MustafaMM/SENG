<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<!-- 	This page allows a user to change their password. 
	Last modified: April 14 2020 -->
<head>
  <title>
    Paper Submission System
</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h3>Change your password</h3>
  </div>
	 
  <form method="post" action="login.php">

  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Current Password</label>
  		<input type="password" name="currentPassword" >
  	</div>
  	<div class="input-group">
  		<label>New Password</label>
  		<input type="password" name="password1">
  	</div>
	<div class="input-group">
  		<label>Confirm Password</label>
  		<input type="password" name="password2">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="changePassword">Change Password</button>
  	</div>
  	<p> <a href="home.php" style="color: blue;">Home</a> </p>
  </form>
</body>
</html>
