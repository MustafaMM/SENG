<!-- 	This script handles uploading of files.
	Last modified: April 14 2020 -->
<?php
session_start();

include('database.php');

//getting user upload file

$file = $_FILES["file"];

if(!getSubmission($_POST['subId'])) {
	newSubmission(strval($_POST['subId']) ."_" .$file["name"], $_SESSION['userId']);
}
else {
	updateSubmissionFile($_POST['subId'], strval($_POST['subId']) ."_" .$file["name"]);
}
//saving file in uploads folder

move_uploaded_file($file["tmp_name"], "uploads/" .strval($_POST['subId']) ."_" .$file["name"]);

//redirecting back to home

header("Location: researcher.php");
