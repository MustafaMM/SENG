
<!DOCTYPE html>
<html> 
<!-- 	This page displays all of the reviewers in the system, ranked from best to worst.
	Last modified: April 14 2020 -->      
<head> 
    <title> 
      Paper Submission System
    </title> 
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 


<body style="text-align:center;">
<h3 class="header">Top Reviewers</h3> 
<div class="content">
<?php
	ini_set('display_errors', 1); 
	ini_set('display_startup_errors', 1); 
	error_reporting(E_ALL);
	session_start();
	// comparison function to sort 2D array
	function sortByTime($a, $b) {
    		return $a[0] - $b[0];
	}
	
	include('database.php');
	$reviewers = getReviewers();
	$reviewerRankings = array();
	// add each reviewer to an array
	for($i = 0;$i < count($reviewers);$i++) {
		$total = 0;
		$reviewed = 0;
		$reviews = getReviewerReviews($reviewers[$i][0]);
		// calculate the reviewer's average time to review a submission
		for($j = 0;$j < count($reviews);$j++) {
			if($reviews[$j][4] != "none") {
				$total = $total + intval(date_diff(date_create($reviews[$j][4]), date_create(getSubmission($reviews[$j][1])[6]), TRUE)->format('d'));
				$reviewed++;
			}
		}
		// store the reviewer with their average review time or a maximum value if they have not reviwed any submissions yet
		if($reviewed > 0) {
			array_push($reviewerRankings, array($total / $reviewed, $reviewers[$i][1]));
		}
		else {
			array_push($reviewerRankings, array(2147483648, $reviewers[$i][1]));
		}
	}
	// sort the reviewers by average response time and display the rankings
	usort($reviewerRankings, 'sortByTime');
	for($i = 0;$i < count($reviewerRankings);$i++) {
		?> 
			<div><?php echo strval($i+1) .": " .$reviewerRankings[$i][1]; ?></div>
		<?php
	}
	

?>
</div>
<p> <a href="home.php" style="color: blue;">Home</a> </p>
</body>

</html>
