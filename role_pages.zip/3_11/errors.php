<!-- 	This script displays error messages for login and registration errors.
	Last modified: April 14 2020 -->
<?php
if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
<?php  endif ?>
