<!DOCTYPE html>
<html> 
<!-- 	This is the home page for editors.
	Last modified: April 14 2020 -->
<head> 
    <title> 
      Paper Submission System
    </title> 
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
  
<body style="text-align:center;"> 

<a href="assign.php"><button type="button">Assign Reviewers</button></a>
<a href="decision.php"><button type="button">Review Submissions</button></a>


<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
<p> <a href="rankings.php" style="color: blue;">See Top Reviewers</a> </p>
<p> <a href="changepass.php" style="color: red;">Change Password</a> </p>
</body>

</html>
