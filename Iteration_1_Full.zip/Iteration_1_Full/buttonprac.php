<!DOCTYPE html> 
<html> 
      
<head> 
    <title> 
        How to call PHP function 
        on the click of a Button ? 
    </title> 
</head> 
  
<body style="text-align:center;"> 
      
    <h1 style="color:green;"> 
       Paper Submission System
    </h1> 
      
    <h4> 
       Welcome to the webpage! Please select whether you are a researcher or reviewer.
    </h4> 
      
    <?php
        if(array_key_exists('button1', $_POST)) { 
            button1(); 
        } 
        else if(array_key_exists('button2', $_POST)) { 
            button2(); 
        } 
        function button1() { 
            //echo "This is Button1 that is selected"; 
            header("Location: work.php");
        } 
        function button2() { 
                $files = scandir("uploads"); 
                //print_r($files);
                for($a = 2; $a < count($files); $a++)
                    {
                        //displaying links to download
                        //making it downloadable
                        ?>
                        <p>
                        <a download="<?php echo $files[$a] ?>" href="uploads/<?php echo $files[$a] ?>"><?php echo $files[$a] ?></a>
                        </p>
                        <?php
                    }
        } 
    ?> 
  
    <form method="post"> 
        <input type="submit" name="button1"
                class="button" value="Researcher" /> 
          
        <input type="submit" name="button2"
                class="button" value="Reviewer" /> 
    </form> 
</head> 
  
</html> 