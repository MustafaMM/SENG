<?php

//creating directory to store files
//designing user interface
header("Location: main.php");
?>